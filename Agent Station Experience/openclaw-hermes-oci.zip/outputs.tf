output "app" {
  description = "Selected chat app."
  value       = local.selected_app
}

output "region_source" {
  description = "The OCI provider region is read from the environment. The VM bootstrap also reads its own region from instance metadata."
  value       = "environment/provider + instance metadata"
}

output "selected_shape" {
  description = "Shape selected by priority. E5 is preferred; E6 is fallback."
  value       = local.selected_shape
}

output "selected_availability_domain" {
  description = "Availability domain selected from the capacity report."
  value       = local.selected_ad
}

output "public_ip" {
  description = "Public IP of the chat VM."
  value       = local.public_ip
}

output "chat_url" {
  description = "Open the selected app here. During bootstrap this serves a temporary status page, then switches to the dashboard."
  value       = local.app_url
}

output "openclaw_chat_url" {
  description = "OpenClaw URL when app=openclaw."
  value       = local.selected_app == "openclaw" ? local.app_url : ""
}

output "openclaw_gateway_token" {
  description = "Generated OpenClaw gateway token when app=openclaw. The openclaw_chat_url includes it as a URL fragment."
  value       = local.selected_app == "openclaw" ? random_string.openclaw_gateway_token.result : ""
}

output "hermes_chat_url" {
  description = "Hermes dashboard URL when app=hermes."
  value       = local.selected_app == "hermes" ? local.app_url : ""
}

output "hermes_dashboard_username" {
  description = "Hermes dashboard username when app=hermes."
  value       = local.selected_app == "hermes" ? var.hermes_dashboard_username : ""
}

output "ssh_command" {
  description = "SSH command for the generated key. If you supplied ssh_public_key, use your matching private key instead."
  value       = trimspace(var.ssh_public_key) == "" ? "ssh -i ./chat-${random_id.suffix.hex}.pem opc@${local.public_ip}" : "ssh opc@${local.public_ip}"
}

output "generated_private_key_pem" {
  description = "Generated SSH private key. Empty when ssh_public_key is supplied."
  value       = trimspace(var.ssh_public_key) == "" ? tls_private_key.ssh.private_key_openssh : ""
  sensitive   = true
}

output "iam_policy_created" {
  description = "Whether the stack created the dynamic group and Generative AI policy."
  value       = var.create_iam_policy
}
