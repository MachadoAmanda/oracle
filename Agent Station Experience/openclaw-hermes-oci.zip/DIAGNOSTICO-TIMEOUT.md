# Diagnóstico do timeout no OCI Resource Manager

## Conclusão executiva

O job não falhou por falta de capacidade OCI nem durante a criação da VM. A falha foi produzida pelo próprio waiter Terraform, que encerrava obrigatoriamente após 900 segundos. O bootstrap ainda estava na fase `prebuild_hermes_dashboard` quando esse prazo venceu.

O pacote novo remove a corrida observada, troca `npx vite build` pelo comando oficial `npm run build`, mede cada fase, deixa Chromium/Playwright opcional e configura a autenticação atualmente exigida pelo dashboard público do Hermes.

## Linha do tempo observada

| Horário UTC | Evento | Duração/evidência |
| --- | --- | --- |
| 14:17:39 | Início do job e download de providers | Providers prontos às 14:17:43 |
| 14:17:49 | Início do apply | Rede e IAM começaram |
| 14:17:53 | Criação da VM | Terraform reportou conclusão em 24 s |
| 14:18:36 | SSH conectado | O `remote-exec` conseguiu entrar na VM |
| 14:18:37 | Waiter iniciou prazo interno | `deadline = agora + 900` |
| 14:18:53 | `install_host_dependencies` | Primeira fase de cloud-init observada |
| 14:20:25 | `install_proxy_dependencies` | Host/proxy avançaram normalmente |
| 14:20:56 | `install_hermes` | Instalação/configuração avançou |
| 14:22:13 | `prebuild_hermes_dashboard` | Última fase registrada |
| 14:33:36 | Waiter saiu com status 1 | 899 s depois de iniciar; fase havia durado ~11m23s |

O tail coletado no timeout mostrou `Installation Complete`, dependências npm adicionadas, o Vite declarando `built in 657ms` e o serviço `hermes-dashboard.service` sendo habilitado. O bootstrap estava avançando, mas ainda não tinha chegado ao smoke do provider nem escrito `chat-ready.txt`.

Como o waiter antigo registrava só o nome da fase e consultava a cada 10 segundos, ele não prova qual subprocesso dentro do prebuild consumiu os ~11 minutos. O contraste entre ~11m23s da fase e 657 ms reportados pelo Vite aponta para espera anterior ao build efetivo, no caminho de resolução/execução do `npx`. Isso é uma inferência baseada no log, não uma medição direta.

## O que foi corrigido

1. `npx vite build` foi substituído por `npm run build`, que é o comando documentado pelo projeto Hermes.
2. Operações npm de dependências e build receberam limite individual de 600 s e fase identificável.
3. O waiter passou de 900 s fixos para `bootstrap_timeout_minutes`, padrão 45 minutos.
4. O prazo de 45 minutos é apenas teto de segurança; o alvo operacional sem browser tools continua 4–7 minutos sob rede normal.
5. Cada etapa grava `phase_start`, `phase_complete`, `duration_seconds` e duração total.
6. Timeout/erro agora imprime cloud-init, status dos serviços, journal e 200 linhas do bootstrap.
7. `hermes_install_browser_tools` fica `false` por padrão. Ativar Chromium/Playwright é opcional e pode acrescentar vários minutos.
8. O dashboard Hermes recebe usuário, senha escolhida pelo operador e segredo interno estável de sessão. O antigo `--insecure` foi removido.
9. A security list foi reduzida para TCP/22 e a porta do app; os CIDRs são configuráveis.
10. Mudança no bootstrap força substituição da VM, pois a OCI só consome `user_data` no lançamento.
11. `schema.yaml` exige a senha do Hermes como campo mascarado, com confirmação, antes do Apply.

## Estado comprovado

- `terraform fmt -check`: passou.
- `terraform validate` com OCI provider 8.26.0: passou.
- Testes locais do waiter: sucesso, erro imediato e timeout configurável passaram.
- Testes locais do bootstrap: comando de build, modo browser opcional, autenticação e métricas de fase passaram.
- Conteúdo e integridade do ZIP: verificados localmente.

Ainda não foi executado um apply novo na tenancy. Portanto 4–7 minutos é o alvo esperado após remover o gargalo, não uma nova medição OCI.

## Como usar

1. Atualize a configuração da stack com `hermes-oci-ready.zip` ou crie uma stack nova.
2. Mantenha `hermes_install_browser_tools = false` no primeiro teste.
3. Se possível, defina `app_ingress_cidr` como seu IP público com `/32`.
4. Rode Plan e depois Apply.
5. Para Hermes, entre com `hermes_dashboard_username` e a mesma senha definida em `hermes_dashboard_password` na tela `Variables`.
6. No log, procure `phase_complete` para confirmar as durações reais.

## Referências oficiais verificadas

- Terraform recomenda cautela com provisioners e documenta o `remote-exec`: <https://developer.hashicorp.com/terraform/language/provisioners>
- O `timeout` do bloco `connection` limita a espera para a conexão ficar disponível; não era o deadline do bootstrap: <https://developer.hashicorp.com/terraform/language/block/resource>
- O Hermes documenta `npm run build` para gerar o dashboard: <https://github.com/NousResearch/hermes-agent/blob/main/web/README.md>
- O Hermes atual exige autenticação em bind não-loopback e documenta basic auth: <https://github.com/NousResearch/hermes-agent/blob/main/website/docs/user-guide/desktop.md>
- A OCI informa que `user_data` só pode ser definido no lançamento da instância: <https://docs.oracle.com/en-us/iaas/Content/Compute/Tasks/updatinginstancemetada.htm>
