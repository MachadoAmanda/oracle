variable "tenancy_ocid" {
  description = "Root tenancy OCID. Used only to create the dynamic group and IAM policy."
  type        = string
}

variable "compartment_id" {
  description = "Compartment OCID where the VM, VCN, and Generative AI access policy will be scoped."
  type        = string
}

variable "region" {
  description = "OCI region where the stack runs, for example sa-saopaulo-1. When using OCI CLI, set this to the profile region."
  type        = string
}

variable "app" {
  description = "Which chat app to install and expose: openclaw or hermes."
  type        = string
  default     = "hermes"

  validation {
    condition     = contains(["openclaw", "hermes"], lower(var.app))
    error_message = "app must be either openclaw or hermes."
  }
}

variable "create_iam_policy" {
  description = "Create the dynamic group and IAM policy needed for instance principal access to OCI Generative AI."
  type        = bool
  default     = true
}

variable "ssh_public_key" {
  description = "Optional SSH public key. Leave empty to let Terraform generate one and output the private key."
  type        = string
  default     = ""
}

variable "ssh_ingress_cidr" {
  description = "IPv4 CIDR allowed to reach SSH. Keep 0.0.0.0/0 for Resource Manager remote-exec unless you know its egress CIDR or use a private endpoint."
  type        = string
  default     = "0.0.0.0/0"

  validation {
    condition     = can(cidrhost(var.ssh_ingress_cidr, 0))
    error_message = "ssh_ingress_cidr must be a valid IPv4 CIDR, for example 203.0.113.10/32."
  }
}

variable "app_ingress_cidr" {
  description = "IPv4 CIDR allowed to reach the selected dashboard port. Use your public IP with /32 whenever possible."
  type        = string
  default     = "0.0.0.0/0"

  validation {
    condition     = can(cidrhost(var.app_ingress_cidr, 0))
    error_message = "app_ingress_cidr must be a valid IPv4 CIDR, for example 203.0.113.10/32."
  }
}

variable "boot_volume_size_in_gbs" {
  description = "Boot volume size for the chat VM."
  type        = number
  default     = 80
}

variable "bootstrap_timeout_minutes" {
  description = "Maximum time Terraform waits for cloud-init, the selected app, and the provider smoke test."
  type        = number
  default     = 45

  validation {
    condition = (
      var.bootstrap_timeout_minutes >= 10 &&
      var.bootstrap_timeout_minutes <= 120 &&
      floor(var.bootstrap_timeout_minutes) == var.bootstrap_timeout_minutes
    )
    error_message = "bootstrap_timeout_minutes must be a whole number between 10 and 120."
  }
}

variable "hermes_install_browser_tools" {
  description = "Install Hermes Playwright/Chromium browser tooling. Disabled by default to keep first boot predictable; enable it when browser automation is required."
  type        = bool
  default     = false
}

variable "hermes_dashboard_username" {
  description = "Username generated into the Hermes dashboard basic-auth configuration."
  type        = string
  default     = "admin"

  validation {
    condition     = can(regex("^[A-Za-z0-9._-]{1,64}$", var.hermes_dashboard_username))
    error_message = "hermes_dashboard_username must contain 1 to 64 letters, numbers, dots, underscores, or hyphens."
  }
}

variable "hermes_dashboard_password" {
  description = "Hermes dashboard password chosen by the operator before Apply."
  type        = string
  sensitive   = true
  nullable    = false

  validation {
    condition = (
      length(var.hermes_dashboard_password) >= 16 &&
      length(var.hermes_dashboard_password) <= 64 &&
      can(regex("^[A-Za-z0-9._@%+-]+$", var.hermes_dashboard_password)) &&
      can(regex("[A-Z]", var.hermes_dashboard_password)) &&
      can(regex("[a-z]", var.hermes_dashboard_password)) &&
      can(regex("[0-9]", var.hermes_dashboard_password))
    )
    error_message = "hermes_dashboard_password must be 16 to 64 characters, include uppercase, lowercase, and a digit, and use only letters, numbers, dot, underscore, at sign, percent, plus, or hyphen."
  }
}

variable "system_prompt" {
  description = "Default system prompt seeded into the selected app config/workspace."
  type        = string
  default     = "Voce e um assistente util rodando no OCI Generative AI. Responda no idioma da pessoa, de forma simples e direta. Para mensagens normais, cumprimentos ou perguntas gerais, responda naturalmente. Use ferramentas apenas quando a tarefa realmente precisar de uma acao externa."
}
