#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd -P)"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

fail() {
  printf 'FAIL: %s\n' "$*" >&2
  exit 1
}

pass() {
  printf 'PASS: %s\n' "$*"
}

render_wait_script() {
  local output_path="$1"

  sed \
    -e 's/\$\${/\${/g' \
    "$ROOT_DIR/wait-for-chat-ready.sh.tftpl" > "$output_path"
  chmod +x "$output_path"
}

render_bootstrap_script() {
  local output_path="$1"

  sed \
    -e 's/\$\${/\${/g' \
    "$ROOT_DIR/bootstrap.sh.tftpl" > "$output_path"
  chmod +x "$output_path"
}

WAIT_TEMPLATE="$ROOT_DIR/wait-for-chat-ready.sh.tftpl"
[[ -f "$WAIT_TEMPLATE" ]] || fail "wait-for-chat-ready.sh.tftpl is missing"

FAKE_BIN="$TMP_DIR/fake-bin"
mkdir -p "$FAKE_BIN"
for command_name in curl cloud-init systemctl journalctl sudo; do
  printf '#!/usr/bin/env bash\nexit 0\n' > "$FAKE_BIN/$command_name"
  chmod +x "$FAKE_BIN/$command_name"
done

SUCCESS_DIR="$TMP_DIR/success"
mkdir -p "$SUCCESS_DIR"
printf 'app=hermes\n' > "$SUCCESS_DIR/chat-ready.txt"
printf '{"result":"OK"}\n' > "$SUCCESS_DIR/chat-provider-smoke.json"
SUCCESS_SCRIPT="$TMP_DIR/wait-success.sh"
render_wait_script "$SUCCESS_SCRIPT"

SUCCESS_OUTPUT="$(
  app=hermes \
  app_port=9119 \
  openclaw_gateway_token=test-token \
  timeout_seconds=10 \
  CHAT_STATUS_DIR="$SUCCESS_DIR" \
  CHAT_BOOTSTRAP_LOG="$SUCCESS_DIR/bootstrap.log" \
  CHAT_POLL_INTERVAL_SECONDS=1 \
  PATH="$FAKE_BIN:$PATH" \
    bash "$SUCCESS_SCRIPT"
)"
[[ "$SUCCESS_OUTPUT" == *"Chat app is ready"* ]] || fail "ready condition did not complete successfully"
pass "waiter exits only after readiness files and local HTTP check succeed"

ERROR_DIR="$TMP_DIR/error"
mkdir -p "$ERROR_DIR"
printf 'prebuild failed rc=1\n' > "$ERROR_DIR/chat-bootstrap-error.txt"
ERROR_SCRIPT="$TMP_DIR/wait-error.sh"
render_wait_script "$ERROR_SCRIPT"

set +e
ERROR_OUTPUT="$(
  app=hermes \
  app_port=9119 \
  openclaw_gateway_token=test-token \
  timeout_seconds=10 \
  CHAT_STATUS_DIR="$ERROR_DIR" \
  CHAT_BOOTSTRAP_LOG="$ERROR_DIR/bootstrap.log" \
  CHAT_POLL_INTERVAL_SECONDS=1 \
  PATH="$FAKE_BIN:$PATH" \
    bash "$ERROR_SCRIPT" 2>&1
)"
ERROR_RC=$?
set -e
[[ "$ERROR_RC" -eq 1 ]] || fail "bootstrap error file should stop the waiter with exit 1"
[[ "$ERROR_OUTPUT" == *"Bootstrap reported an error"* ]] || fail "bootstrap error was not explained"
pass "waiter fails fast when cloud-init reports a bootstrap error"

TIMEOUT_DIR="$TMP_DIR/timeout"
mkdir -p "$TIMEOUT_DIR"
printf '2026-08-11T14:22:13+00:00 prebuild_hermes_dashboard\n' > "$TIMEOUT_DIR/chat-bootstrap-progress.txt"
TIMEOUT_SCRIPT="$TMP_DIR/wait-timeout.sh"
render_wait_script "$TIMEOUT_SCRIPT"

START_SECONDS=$SECONDS
set +e
TIMEOUT_OUTPUT="$(
  app=hermes \
  app_port=9119 \
  openclaw_gateway_token=test-token \
  timeout_seconds=1 \
  CHAT_STATUS_DIR="$TIMEOUT_DIR" \
  CHAT_BOOTSTRAP_LOG="$TIMEOUT_DIR/bootstrap.log" \
  CHAT_POLL_INTERVAL_SECONDS=1 \
  PATH="$FAKE_BIN:$PATH" \
    bash "$TIMEOUT_SCRIPT" 2>&1
)"
TIMEOUT_RC=$?
set -e
ELAPSED_SECONDS=$((SECONDS - START_SECONDS))
[[ "$TIMEOUT_RC" -eq 1 ]] || fail "timeout should exit 1"
[[ "$ELAPSED_SECONDS" -le 4 ]] || fail "configured one-second timeout was ignored"
[[ "$TIMEOUT_OUTPUT" == *"Timed out after 1 seconds"* ]] || fail "timeout duration was not reported"
[[ "$TIMEOUT_OUTPUT" == *"prebuild_hermes_dashboard"* ]] || fail "last phase was not included in timeout diagnostics"
pass "waiter honors the configured deadline and reports the last phase"

BOOTSTRAP_SCRIPT="$TMP_DIR/bootstrap.sh"
render_bootstrap_script "$BOOTSTRAP_SCRIPT"
bash -n "$BOOTSTRAP_SCRIPT"

export CHAT_BOOTSTRAP_TEST_MODE=1
export app=hermes
export compartment_id=ocid1.compartment.oc1..test
export openclaw_gateway_token=test-token
export system_prompt_b64=VGVzdGU=
export hermes_install_browser_tools=false
export hermes_dashboard_username=test-admin
export hermes_dashboard_password=test-password
export hermes_dashboard_secret=test-signing-secret
# shellcheck source=/dev/null
source "$BOOTSTRAP_SCRIPT"
unset CHAT_BOOTSTRAP_TEST_MODE
PRODUCTION_SET_PHASE_DEFINITION="$(declare -f set_phase)"

CAPTURED_BUILD_COMMAND=""
set_phase() { :; }
run_as_opc() {
  CAPTURED_BUILD_COMMAND="$1"
}
prebuild_hermes_dashboard
[[ "$CAPTURED_BUILD_COMMAND" == *"npm run build"* ]] || fail "dashboard build must use the repository's official npm build script"
[[ "$CAPTURED_BUILD_COMMAND" != *"npx vite build"* ]] || fail "dashboard build still uses npx package resolution"
pass "Hermes dashboard invokes the official npm build script without npx resolution"

CAPTURED_INSTALL_COMMAND=""
run_as_opc() {
  case "$1" in
    "test -x /home/opc/.local/bin/hermes") return 1 ;;
    "curl -fsSL "*) return 0 ;;
    *) CAPTURED_INSTALL_COMMAND="$1"; return 0 ;;
  esac
}
HERMES_INSTALL_BROWSER_TOOLS="false"
install_hermes
[[ "$CAPTURED_INSTALL_COMMAND" == *"--skip-setup"* ]] || fail "non-interactive installer must explicitly skip setup"
[[ "$CAPTURED_INSTALL_COMMAND" == *"--non-interactive"* ]] || fail "installer must be explicitly non-interactive"
[[ "$CAPTURED_INSTALL_COMMAND" == *"--skip-browser"* ]] || fail "fast mode must skip the optional Chromium download"

HERMES_INSTALL_BROWSER_TOOLS="true"
CAPTURED_INSTALL_COMMAND=""
install_hermes
[[ "$CAPTURED_INSTALL_COMMAND" != *"--skip-browser"* ]] || fail "full mode must retain optional browser tooling"
pass "Hermes browser-tool installation is explicit and configurable"

declare -F write_hermes_environment_files >/dev/null || fail "Hermes authenticated environment writer is missing"
declare -F write_hermes_dashboard_service >/dev/null || fail "Hermes dashboard service writer is missing"

USER_ENV_FILE="$TMP_DIR/hermes-user.env"
SERVICE_ENV_FILE="$TMP_DIR/hermes-service.env"
write_hermes_environment_files "$USER_ENV_FILE" "$SERVICE_ENV_FILE"
grep -Fqx 'HERMES_DASHBOARD_BASIC_AUTH_USERNAME=test-admin' "$USER_ENV_FILE" || fail "Hermes username was not written"
grep -Fqx 'HERMES_DASHBOARD_BASIC_AUTH_PASSWORD=test-password' "$USER_ENV_FILE" || fail "Hermes password was not written"
grep -Fqx 'HERMES_DASHBOARD_BASIC_AUTH_SECRET=test-signing-secret' "$USER_ENV_FILE" || fail "Hermes stable session secret was not written"
cmp -s "$USER_ENV_FILE" "$SERVICE_ENV_FILE" || fail "Hermes user and systemd environments differ"

SERVICE_FILE="$TMP_DIR/hermes-dashboard.service"
write_hermes_dashboard_service "$SERVICE_FILE"
grep -Fq 'EnvironmentFile=' "$SERVICE_FILE" || fail "Hermes service does not load its authenticated environment"
grep -Fq 'hermes dashboard --host 0.0.0.0' "$SERVICE_FILE" || fail "Hermes dashboard command is missing"
if grep -Fq -- '--insecure' "$SERVICE_FILE"; then
  fail "Hermes service still relies on the deprecated insecure bypass"
fi
pass "Hermes public dashboard is configured with basic authentication"

eval "$PRODUCTION_SET_PHASE_DEFINITION"
declare -F complete_current_phase >/dev/null || fail "phase completion timing is missing"
declare -F phase_now_epoch >/dev/null || fail "phase clock is not testable"
declare -F phase_now_iso >/dev/null || fail "phase timestamp clock is not testable"

PROGRESS_FILE="$TMP_DIR/phase-progress.txt"
CURRENT_PHASE=""
CURRENT_PHASE_STARTED_EPOCH=0
TEST_PHASE_EPOCH=100
CAPTURED_PHASE_LOG=""
phase_now_epoch() { printf '%s\n' "$TEST_PHASE_EPOCH"; }
phase_now_iso() { printf '2026-08-11T12:00:%02d+00:00\n' "$((TEST_PHASE_EPOCH % 60))"; }
log() { CAPTURED_PHASE_LOG="$CAPTURED_PHASE_LOG$*"$'\n'; }
chown() { :; }

set_phase "download_dependencies"
TEST_PHASE_EPOCH=137
set_phase "build_dashboard"
[[ "$CAPTURED_PHASE_LOG" == *"phase_complete name=download_dependencies duration_seconds=37"* ]] || fail "completed phase duration was not logged"
[[ "$(cat "$PROGRESS_FILE")" == *"build_dashboard"* ]] || fail "current phase was not written to progress"

TEST_PHASE_EPOCH=145
complete_current_phase
[[ "$CAPTURED_PHASE_LOG" == *"phase_complete name=build_dashboard duration_seconds=8"* ]] || fail "final phase duration was not logged"
pass "bootstrap logs deterministic start and duration for every phase"
trap - ERR

VALID_PASSWORD='ChosenPass2026AB'
set +e
PASSWORD_FLOW_OUTPUT="$(
  printf '%s\n' 'nonsensitive(local.hermes_dashboard_auth.password)' | \
    terraform -chdir="$ROOT_DIR" console -no-color \
      -var='tenancy_ocid=ocid1.tenancy.oc1..test' \
      -var='compartment_id=ocid1.compartment.oc1..test' \
      -var='region=us-chicago-1' \
      -var="hermes_dashboard_password=$VALID_PASSWORD" 2>&1
)"
PASSWORD_FLOW_RC=$?
set -e
[[ "$PASSWORD_FLOW_RC" -eq 0 ]] || fail "operator-selected Hermes password did not reach the Terraform authentication local: $PASSWORD_FLOW_OUTPUT"
[[ "$PASSWORD_FLOW_OUTPUT" == '"ChosenPass2026AB"' ]] || fail "Terraform changed the operator-selected Hermes password"

set +e
WEAK_PASSWORD_OUTPUT="$(
  terraform -chdir="$ROOT_DIR" plan -refresh=false -input=false -lock=false -no-color \
      -target=terraform_data.bootstrap_revision \
      -var='tenancy_ocid=ocid1.tenancy.oc1..test' \
      -var='compartment_id=ocid1.compartment.oc1..test' \
      -var='region=us-chicago-1' \
      -var='hermes_dashboard_password=weakpassword' 2>&1
)"
WEAK_PASSWORD_RC=$?
set -e
[[ "$WEAK_PASSWORD_RC" -ne 0 ]] || fail "weak Hermes password unexpectedly passed Terraform validation"
[[ "$WEAK_PASSWORD_OUTPUT" == *"hermes_dashboard_password must"* ]] || fail "weak password failure did not explain the password requirements"

SCHEMA_CHECK="$(
  terraform -chdir="$ROOT_DIR" console -no-color <<'EOF'
alltrue([length(yamldecode(file("schema.yaml")).title) > 0, length(yamldecode(file("schema.yaml")).description) > 0, yamldecode(file("schema.yaml")).schemaVersion == "1.1.0", yamldecode(file("schema.yaml")).variables.hermes_dashboard_password.type == "password", yamldecode(file("schema.yaml")).variables.hermes_dashboard_password.confirmation == true, yamldecode(file("schema.yaml")).variables.hermes_dashboard_password.required == true, !contains(keys(yamldecode(file("schema.yaml")).outputs), "hermes_dashboard_password")])
EOF
)" || fail "OCI console schema could not be decoded"
[[ "$SCHEMA_CHECK" == "true" ]] || fail "OCI schema must collect and confirm the Hermes password before Apply"
pass "operator-selected Hermes password is validated and collected before Apply"

terraform -chdir="$ROOT_DIR" fmt -check -recursive >/dev/null
pass "Terraform files are formatted"

printf 'All package behavior tests passed.\n'
